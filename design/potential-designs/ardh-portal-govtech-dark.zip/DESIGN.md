---
name: Sovereign Civic Land Guard
colors:
  surface: '#0f131c'
  surface-dim: '#0f131c'
  surface-bright: '#353942'
  surface-container-lowest: '#0a0e16'
  surface-container-low: '#181c24'
  surface-container: '#1c2028'
  surface-container-high: '#262a33'
  surface-container-highest: '#31353e'
  on-surface: '#dfe2ee'
  on-surface-variant: '#bbcabf'
  inverse-surface: '#dfe2ee'
  inverse-on-surface: '#2c3039'
  outline: '#86948a'
  outline-variant: '#3c4a42'
  surface-tint: '#4edea3'
  primary: '#4edea3'
  on-primary: '#003824'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#006c49'
  secondary: '#68dba9'
  on-secondary: '#003825'
  secondary-container: '#25a475'
  on-secondary-container: '#00311f'
  tertiary: '#45dfa4'
  on-tertiary: '#003825'
  tertiary-container: '#00b982'
  on-tertiary-container: '#00422c'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#85f8c4'
  secondary-fixed-dim: '#68dba9'
  on-secondary-fixed: '#002114'
  on-secondary-fixed-variant: '#005137'
  tertiary-fixed: '#68fcbf'
  tertiary-fixed-dim: '#45dfa4'
  on-tertiary-fixed: '#002114'
  on-tertiary-fixed-variant: '#005137'
  background: '#0f131c'
  on-background: '#dfe2ee'
  surface-variant: '#31353e'
typography:
  display-hero:
    fontFamily: Noto Sans
    fontSize: 2.75rem
    fontWeight: '700'
    lineHeight: 3.25rem
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Noto Sans
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.5rem
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Noto Sans
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.5rem
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Noto Sans
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: 0em
  headline-md:
    fontFamily: Noto Sans
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Noto Sans
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
  title-md:
    fontFamily: Noto Sans
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.5rem
  body-lg:
    fontFamily: Noto Sans
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.625rem
  body-md:
    fontFamily: Noto Sans
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.375rem
  body-sm:
    fontFamily: Noto Sans
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1.125rem
  label-code:
    fontFamily: JetBrains Mono
    fontSize: 0.8125rem
    fontWeight: '500'
    lineHeight: 1rem
    letterSpacing: 0.02em
  label-badge:
    fontFamily: Noto Sans
    fontSize: 0.6875rem
    fontWeight: '700'
    lineHeight: 0.875rem
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system establishes an authoritative, sovereign, high-readability digital workspace for land administration, cadastral record management, and civic property monitoring. Rooted in the institutional gravitas of the Bangladesh Ministry of Land, the aesthetic fuses civic reliability with mission-critical security operations.

The visual direction combines modern enterprise minimalism with technical command-center precision:
- **Sovereign Authority:** Deep midnight slates eliminate glare during extended night field operations and regional registry shifts while projecting stability and institutional integrity.
- **Bioluminescent Accents:** High-vibrancy emerald and mint greens invoke the sovereign identity of Bangladesh, repurposed as high-contrast functional status indicators and key call-to-actions.
- **Tactical Utility:** Dense, structured data modules with high optical contrast ensure parcel records, deeds, geo-coordinates, and mutation verification flags remain unmistakable under variable field lighting.
- **Authentic Civic Demarcation:** Sharp, purposeful information hierarchies respect dual-script contexts (Bengali and Latin) with balanced baseline rendering and uncompromised legibility.

## Colors

The palette is tuned exclusively for high-contrast dark environments, preventing eye fatigue during nocturnal monitoring shifts while exceeding WCAG AAA legibility metrics.

### Canvas & Surface Hierarchy
- **Canvas Base (`#0b0f17`):** The absolute foundation layer for the root viewport.
- **Surface Primary (`#0f172a`):** Base structural container for primary grid zones and sidebars.
- **Surface Secondary (`#111827`):** Raised card and module fill providing distinct foreground separation.
- **Surface Tertiary / Accent (`#1e293b`):** Active selections, table headers, hover states, and structural dividers.

### Sovereign Chromatic Tokens
- **Primary Brand Green (`#10b981`):** High-luminance emerald for dominant actions, active validation, and sovereign verification badges.
- **Deep Forest (`#059669`):** Grounded interaction state for pressed or focused primary elements.
- **Mint Radiance (`#34d399`):** Accent highlights, focus halos, cadastral parcel boundary indicators, and verified status dots.

### Functional Alerts & Status
- **Warning Amber (`#f59e0b`):** Disputed deeds, pending registry approvals, and land tax encumbrances.
- **Danger Crimson (`#ef4444`):** Cadastral overlaps, fraudulent deed warnings, mutation rejections, and expired leases.
- **Audit Success (`#10b981`):** Uncontested ownership verification and cleared biometric signatures.

### Text & Delimiters
- **Text Primary (`#ffffff`):** Unyielding pure white for titles, vital parcel metrics, and critical telemetry.
- **Text Secondary (`#cbd5e1`):** Crisp cool gray for body data, metadata labels, and civic instructions.
- **Text Muted (`#94a3b8`):** Timestamp data, inactive navigation items, and secondary labels.
- **Border Structural (`#1e293b`):** Base boundary strokes for cards and table rows.
- **Border Interactive (`#334155`):** Input boundaries and hover-active card perimeters.

## Typography

Typography handles complex multi-script civic content: English administrative jargon, cadastral deed references, and Bengali script (Khatian, Dag, Mouza records). 

- **Primary & Headings:** `Noto Sans` is configured with direct fallback to `Noto Sans Bengali` and `Hind Siliguri`. This ensures conjoints (যুক্তবর্ণ) render without clipping or artificial baseline shifting alongside alphanumeric identifiers.
- **Technical & Cadastral Labeling:** `JetBrains Mono` handles Plot/Dag IDs, Mouza coordinates, transaction hashes, and surveyor token signatures, reinforcing numerical distinction between `0`, `O`, `1`, and `I`.
- **Vertical Metrics:** Due to Bengali vowel markers (matras and kar symbols), line heights are spaced at 1.4x–1.6x of the font size to prevent overlapping ascenders and descenders.

## Layout & Spacing

The layout utilizes a structured 12-column responsive fluid grid designed for dual contexts: heavy dashboard operations (desktop command center) and handheld surveyor inspections (mobile/tablet in field conditions).

### Breakpoints & Reflow
- **Desktop (>= 1280px):** 12-column layout with 24px (`1.5rem`) gutters and 32px (`2rem`) margins. Supports side-by-side cadastral GIS mapping panels alongside ledger verification queues.
- **Tablet (768px – 1279px):** 8-column layout with 16px (`1rem`) gutters and 24px (`1.5rem`) margins. Auxiliary inspection sidebars collapse into drawer sheets.
- **Mobile (< 768px):** 4-column layout with 16px (`1rem`) gutters and 16px (`1rem`) margins. Complex cadastral tables reflow into stacked civic verification cards.

### Spacing Principles
- Spatial rhythm adheres to a clean 4px/8px modular base. 
- Compact component padding (`space-xs`, `space-sm`) maintains data density inside data tables, ledger manifests, and citizen record lists without sacrificing touch targets.

## Elevation & Depth

To avoid murky shadows in deep slate dark mode, the design system constructs optical depth through **calibrated tonal luminance layering** and **subtle perimeter illumination**:

- **Ground Layer (Canvas 0):** `#0b0f17` serves as the foundational viewport canvas.
- **Base Level (Layer 1):** `#0f172a` bordered by a 1px solid stroke of `#1e293b`. No drop shadow. Used for global layout panels and pinned registries.
- **Interactive Container (Layer 2):** `#111827` bordered by `#334155`. Applied to parcel cards, verification popovers, and deed inspect modals. Enhanced with an ultra-subtle ambient shadow: `0 10px 25px -5px rgba(0, 0, 0, 0.6)`.
- **Sovereign Focus State:** Elements in focus or undergoing real-time audit updates gain a localized bioluminescent aura: `0 0 0 1px #10b981, 0 0 20px -2px rgba(16, 185, 129, 0.25)`.
- **Overlays & Dialogs:** `#111827` backdrop combined with a 40% blur screen (`backdrop-filter: blur(12px)`) over `#0b0f17` at 80% opacity, maintaining focus on critical authentication steps.

## Shapes

The design uses soft, disciplined geometry (`roundedness: 1`). Radii are deliberately restrained to maintain the technical rigor appropriate for state-level legal documents and surveying equipment:

- **Inputs, Buttons, and Table Badges:** Base 4px (`0.25rem`) radius provides crisp, purposeful corners.
- **Cards, Modals, and Cadastral Overlays:** 8px (`0.5rem`) radius (`rounded-lg`) balances modern ergonomics with high structural stability.
- **Action Pills and Status Tags:** 12px (`0.75rem`) radius (`rounded-xl`) reserved exclusively for micro-tags and live status markers to stand out from structural card grids.

## Components

### Buttons
- **Primary Sovereign Action:** Solid `#10b981` background, `#0b0f17` pure charcoal text (ensuring maximum legibility), bold 600 weight. Active state transitions to `#059669`. Focus halo employs `#34d399` at 40% opacity.
- **Secondary Civic Outline:** Background transparent, border 1px solid `#334155`, text `#ffffff`. Hover shifts background to `#1e293b` with border transitioning to `#10b981`.
- **Destructive Action:** Semi-translucent `#ef4444` background at 15% opacity, border 1px solid `#ef4444`, text `#ef4444`. Hover elevates to 100% solid `#ef4444` with `#ffffff` text.

### Cadastral & Mutation Cards
- Containers use `#111827` surface with a 1px `#1e293b` perimeter stroke.
- Header bands display parcel metadata (Mouza, JL Number, Dag/Khatian) paired with monospace technical chips for Plot Hash strings.
- Interactive states brighten the border to `#334155` and introduce a high-altitude green edge accent (2px solid `#10b981` on the left border).

### Chips & Status Indicators
- **Verified / Clear Deed:** `#10b981` at 12% fill, `#10b981` text, 1px `#10b981` at 30% border, accompanied by a 6px glowing mint status circle.
- **Disputed / Pending Mutation:** `#f59e0b` at 12% fill, `#f59e0b` text, 1px `#f59e0b` at 30% border.
- **Encumbered / Frozen Record:** `#ef4444` at 12% fill, `#ef4444` text, 1px `#ef4444` at 30% border.

### Input Fields & Search Queries
- Fields feature a `#0f172a` recessed base with a 1px `#1e293b` stroke. Text sits at `#ffffff` with `#94a3b8` placeholder text.
- Focus switches border to `#10b981` with an inner 1px glow.
- Integrated search accommodates dual Bengali script and alphanumeric deed identifiers, supporting seamless NID/Khatian lookups.

### Checkboxes & Radio Controls
- Base control: 16x16px frame with `#0f172a` interior and `#334155` border stroke.
- Selected state: Background switches to `#10b981`, checkmark rendered in `#0b0f17` high-contrast slate.

### Specialized Cadastral Data Tables
- Header cells: `#0f172a` background, `#94a3b8` uppercase label typography, 1px bottom border of `#1e293b`.
- Data cells: Zebra-free alternating rows relying on hover fills (`#1e293b` at 50% opacity) for dense tracking across multi-column parcel registries.