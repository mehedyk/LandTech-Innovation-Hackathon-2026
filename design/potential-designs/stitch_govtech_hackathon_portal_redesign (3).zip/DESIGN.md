---
name: Ardh Guard Sovereign Civic
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#3f4944'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#6f7a73'
  outline-variant: '#bec9c2'
  surface-tint: '#046c50'
  primary: '#00503a'
  on-primary: '#ffffff'
  primary-container: '#006a4e'
  on-primary-container: '#92e7c3'
  inverse-primary: '#83d7b4'
  secondary: '#bb0112'
  on-secondary: '#ffffff'
  secondary-container: '#e02928'
  on-secondary-container: '#fffbff'
  tertiary: '#6b3800'
  on-tertiary: '#ffffff'
  tertiary-container: '#8e4b00'
  on-tertiary-container: '#ffcba4'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#9ef4d0'
  primary-fixed-dim: '#83d7b4'
  on-primary-fixed: '#002116'
  on-primary-fixed-variant: '#00513b'
  secondary-fixed: '#ffdad6'
  secondary-fixed-dim: '#ffb4ab'
  on-secondary-fixed: '#410002'
  on-secondary-fixed-variant: '#93000b'
  tertiary-fixed: '#ffdcc3'
  tertiary-fixed-dim: '#ffb77d'
  on-tertiary-fixed: '#2f1500'
  on-tertiary-fixed-variant: '#6e3900'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  headline-xl:
    fontFamily: Inter, 'Noto Sans Bengali', sans-serif
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Inter, 'Noto Sans Bengali', sans-serif
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Inter, 'Noto Sans Bengali', sans-serif
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter, 'Noto Sans Bengali', sans-serif
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 30px
    letterSpacing: '0'
  headline-md:
    fontFamily: Inter, 'Noto Sans Bengali', sans-serif
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Inter, 'Noto Sans Bengali', sans-serif
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter, 'Noto Sans Bengali', sans-serif
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter, 'Noto Sans Bengali', sans-serif
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter, 'Noto Sans Bengali', sans-serif
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Inter, 'Noto Sans Bengali', sans-serif
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter, 'Noto Sans Bengali', sans-serif
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter, 'Noto Sans Bengali', sans-serif
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.03em
  code-md:
    fontFamily: monospace
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The design system embodies the institutional authority, legal finality, and democratic accessibility expected of the Ministry of Land (ভূমি মন্ত্রণালয়). The interface must project uncompromised integrity, legal transparency, and calm bureaucratic certitude to citizens, land registrars, and legal authorities alike.

The design movement is **Civic Structuralist**—a synthesis of high-contrast institutional reliability, crisp documentary structure, and clear legibility. It rejects transient web trends, excessive drop shadows, and ornamental gradients in favor of structured data sheets, authoritative seal iconography, tactile certification badges, and razor-sharp ledger grids. Visual weight prioritizes instant verification: records are indisputable, legal alerts are impossible to miss, and generational lineage (CS, SA, RS, BS) reads with archival rigor.

## Colors

The palette directly anchors to the sovereign identity of the People's Republic of Bangladesh, elevated for high-density document verification:

- **Primary (`#006A4E`)**: Bangladesh Official Forest Green. Used for primary navigation headers, verified authentic credentials, authoritative action triggers, and active ledger nodes. Supported by Deep Jade (`#064E3B`) for elevated structural headers and Emerald (`#059669`) for positive interactive accents.
- **Secondary / National Alert (`#DC2626` / `#B91C1C`)**: Critical legal disputes, forged signatures, flagged anomalies, and contested inheritance caveats.
- **Tertiary / Sovereign Seal Gold (`#D97706` / `#F59E0B`)**: State seals, official revenue notations, archival flags, and pending AC Land approvals.
- **Neutrals**: Grounded in cool slate tones. High-contrast typography is rendered in Slate 900 (`#0F172A`) and Slate 700 (`#334155`). Subordinate ledger captions use Slate 500 (`#64748B`). Surfaces rest on pristine Canvas White (`#FFFFFF`) framed against crisp structural dividers (`#E2E8F0` and `#CBD5E1`) and ambient ledger grounds (`#F8FAFC`).
- **Semantic Enclosures**: Verification states always pair saturated indicator borders with ultra-tinted backgrounds for effortless readability: Verified Green (`#DCFCE7` with `#15803D` text), Risk/Caveat Amber (`#FEF3C7` with `#B45309` text), State Land/Khas Alert Red (`#FEE2E2` with `#B91C1C` text), and Statutory Guidance Blue (`#DBEAFE` with `#1D4ED8` text).

## Typography

Typography prioritizes bilingual parity between Bangla and English script. When rendering Bengali script, system stacks default to `'Hind Siliguri'` or `'Noto Sans Bengali'`, falling back to high-grade system sans-serif. When rendering Latin characters and numerals, `Inter` guarantees tabular alignment.

To preserve legibility across dense cadastral records (খতিয়ান নম্বর, দাগ নম্বর, মৌজা, জেএল নম্বর):
- Tabular figures (`tnum`) and slashed zeros must be enabled globally for all numerals, land shares (আনা, গণ্ডা, কড়া, ক্রান্তি), and decimal plot calculations.
- Line heights in bilingual text are intentionally expanded to accommodate Bengali vowel signs (হ্রস্ব-ই-কার, দীর্ঘ-উ-কার, র-ফলা) without clipping diacritics.
- Document keys and survey identifiers use uppercase or semi-bold badges (`label-sm` or `label-md`) to ensure instantaneous scanning.

## Layout & Spacing

The portal adheres to a strict 12-column fixed-max grid on desktop (max width `1360px`) with a fluid gutter rhythm. This prevents excessive line lengths for legal text while providing balanced columns for comparative land survey tracking.

- **Desktop (1024px and up)**: 12-column layout, `2rem` outer margins, `1.25rem` column gutters. Dedicated right rail for QR notary validation and certificate issuance.
- **Tablet (768px - 1023px)**: 8-column layout, `1.5rem` outer margins, `1rem` column gutters. Multi-generation ledger cards switch to a synchronized horizontal scroll carousel.
- **Mobile (< 768px)**: 4-column layout, `1rem` margins, `0.75rem` gutters. Top utility bars stack vertically; land survey matrices collapse into accordion lineage modules.

Inner component padding preserves documentary compact density: inputs and table cells utilize `space-sm` vertically and `space-md` horizontally.

## Elevation & Depth

Visual hierarchy relies on structural planes and precision borders rather than heavy atmospheric shadows, reflecting official paper records:

- **Level 0 (Base Canvas)**: Flat `#F8FAFC`, non-elevated, structured only by grid dividing rules.
- **Level 1 (Data Cards & Ledger Plates)**: Pure white `#FFFFFF` bounded by a 1px solid stroke of `#CBD5E1`. Shadow is minimal: `0 1px 2px rgba(15, 23, 42, 0.05)`.
- **Level 2 (Active Survey Ledger Node / Hover States)**: Lifted card with `0 4px 6px -1px rgba(15, 23, 42, 0.08), 0 2px 4px -2px rgba(15, 23, 42, 0.04)` bordered by `#006A4E` at 1.5px.
- **Level 3 (Modal Certificate & QR Verification Dialogs)**: High-prominence surface with `0 10px 15px -3px rgba(15, 23, 42, 0.12), 0 4px 6px -4px rgba(15, 23, 42, 0.06)`, framed by a distinct 2px top band of National Green (`#006A4E`).
- **Surface Inset**: Used for search bars and verified deed cryptographic hash displays (`#F1F5F9` background, inset border `inset 0 1px 2px rgba(15, 23, 42, 0.06)`).

## Shapes

The design uses **Soft (`roundedness: 1`)** geometry (`0.25rem` / `4px` default radius). 

Curvatures must convey stability and legal authority; exaggerated pills or circular radiuses are strictly limited to micro status indicators and sovereign pill seals. 
- Form inputs, table shells, and primary ledger cards use `4px` corners.
- Verification banners, action buttons, and modal dialogs use `rounded-lg` (`8px` / `0.5rem`).
- Strict rectangular alignment is preferred inside survey comparison grids to emulate traditional survey parcha documents (পর্চা).

## Components

### Official Government Topbar & Civic Header
- **Structure**: Two-tier bar.
  - *Tier 1 (Cabinet Bar)*: Sovereign Deep Jade (`#064E3B`) with gold National Emblem (জাতীয় প্রতীক), "Government of the People's Republic of Bangladesh / Ministry of Land" title, bilingual quick switcher (`বাংলা` | `EN`), and accessibility tools (font-size adjustment `A-`, `A`, `A+`, high-contrast toggle).
  - *Tier 2 (Portal Utility Bar)*: White background featuring the citizen helpline badge `16122 (টোল ফ্রি)` styled as an interactive pill badge, alongside session status and AC Land zonal jurisdiction selector.

### Verification Status Banners
- **Verified Authentic (যাচাইকৃত খতিয়ান)**: Background `#DCFCE7`, Border 1.5px `#15803D`, Text `#14532D`. Accompanied by a bold checkmark seal.
- **Caveat / Dispute Pending (আটকে রাখা / আপত্তি দাখিল)**: Background `#FEF3C7`, Border 1.5px `#B45309`, Text `#78350F`. Prominent alert symbol and court case reference tag.
- **Government Vested / Khas Property (সরকারি খাস জমি / অর্পিত সম্পত্তি)**: Background `#FEE2E2`, Border 2px `#B91C1C`, Text `#7F1D1D`. Displays legal warning: "হস্তান্তর বা নামজারি আইনত দণ্ডনীয় অপরাধ".

### Multi-Generation Survey Ledger Cards
- **Lineage Modules**: Displays generational evolution across CS (১৯১০), SA (১৯৫০), RS (২০০০), and BS (২০১২).
- **Styling**: Cards arranged sequentially with connecting lineage nodes. Active card highlighted in Forest Green border (`#006A4E`); mismatch warnings between surveys flagged with gold or red indicators showing area discrepancies in শতক / একর.

### Tabular Deed Audit Grids
- **Table Anatomy**: Condensed rows, background alternating between `#FFFFFF` and `#F8FAFC`. Header row uses `#F1F5F9` with text `#334155` in `label-sm` uppercase.
- **Row Content**: Columns for দাগ নং (Plot No), খতিয়ান নং (Ledger No), মালিকের নাম ও অংশ (Owner Name & Share), জমির শ্রেণি (Land Class), and যাচাই স্থিতি (Status).
- **Action Column**: Fixed right column with "QR কোড যাচাই", "পর্চা প্রিভিউ", and "ডাউনলোড" actions.

### Buttons & Interactive Controls
- **Primary Action (যাচাই করুন / ডাউনলোড)**: Solid `#006A4E` background, `#FFFFFF` text, `4px` radius, hover `#064E3B`.
- **Secondary Action (আবেদন প্রিন্ট)**: `#FFFFFF` background, 1px `#CBD5E1` border, `#0F172A` text, hover `#F8FAFC`.
- **Danger Action (আপত্তি দাখিল)**: `#DC2626` background, `#FFFFFF` text.

### Inputs & Search Bars
- **Deed Search Form**: Inset white input with `#CBD5E1` border, focusing to a 2px `#006A4E` outline with zero elevation offset. Labels clearly mark division, district, upazila, and mouza dropdowns in a synchronized cascading flow.